**Stylus Supremacy** extension helps formatting **[Stylus](http://stylus-lang.com)** files. It is powered by the Node.js module with the same name and developed by the same developer.

# For features and settings, please visit https://thisismanta.github.io/stylus-supremacy#vscode

[![Demo](https://github.com/ThisIsManta/vscode-stylus-supremacy/raw/master/docs/vscode.gif)](https://thisismanta.github.io/stylus-supremacy#vscode)
